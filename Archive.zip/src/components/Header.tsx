import { useState, type WheelEvent } from "react";
import type { Route } from "../types/store";

type HeaderProps = {
  navLinks: { href: string; label: string }[];
  route: Route;
  activeCategory: string;
  activeQuery: string;
  wishlistCount: number;
  cartCount: number;
  onOpenCart: () => void;
  onShopCategory: (categoryId: string, query?: string) => void;
};

type MegaMenuItem = {
  label: string;
  categoryId: string;
  query?: string;
};

type DesktopLink = {
  id: string;
  label: string;
  categoryId: string;
  query?: string;
  hero: string;
  title: string;
  items: MegaMenuItem[];
};

const desktopLinks: DesktopLink[] = [
  {
    id: "men",
    label: "MEN",
    categoryId: "men",
    query: "polo",
    hero: "/products/product_01_website_square_1600.jpg",
    title: "MEN",
    items: [
      { label: "TEXTURED POLOS", categoryId: "men", query: "polo" },
      { label: "KNIT HENLEYS", categoryId: "men", query: "henley" },
      { label: "NEW IN", categoryId: "men", query: "new-in" },
      { label: "TEXTURED", categoryId: "men", query: "textured" },
      { label: "SAND", categoryId: "men", query: "sand" },
      { label: "ICE", categoryId: "men", query: "ice" },
      { label: "OLIVE", categoryId: "men", query: "olive" },
    ],
  },
  {
    id: "sale",
    label: "SALE",
    categoryId: "all",
    query: "sale",
    hero: "/products/product_04_website_square_1600.jpg",
    title: "SALE",
    items: [
      { label: "TEXTURED POLO SALE", categoryId: "all", query: "sale" },
      { label: "SAND SALE", categoryId: "men", query: "sand" },
      { label: "OLIVE SALE", categoryId: "men", query: "olive" },
    ],
  },
];

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="11" cy="11" r="6.7" />
      <path d="M16.2 16.2 20 20" />
    </svg>
  );
}

function HeartIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 20.4 4.9 13.6a4.6 4.6 0 0 1 6.5-6.5L12 7.7l.6-.6a4.6 4.6 0 0 1 6.5 6.5Z" />
    </svg>
  );
}

function UserIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="12" cy="8.2" r="3.7" />
      <path d="M5.2 20c.9-3.5 3.1-5.3 6.8-5.3s5.9 1.8 6.8 5.3" />
    </svg>
  );
}

function BagIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M5 8.4h14l-.9 11.4H5.9z" />
      <path d="M9 8.4V7a3 3 0 0 1 6 0v1.4" />
    </svg>
  );
}

export function Header({
  navLinks,
  route,
  activeCategory,
  activeQuery,
  wishlistCount,
  cartCount,
  onOpenCart,
  onShopCategory,
}: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  function isActive(href: string) {
    return (
      (route.page === "home" && href === "#/") ||
      (route.page !== "home" && href === `#/${route.page}`)
    );
  }

  function closeMenu() {
    setMenuOpen(false);
  }

  function keepMegaMenuScroll(event: WheelEvent<HTMLDivElement>) {
    const menu = event.currentTarget;
    const canScroll = menu.scrollHeight > menu.clientHeight;

    if (!canScroll) {
      event.preventDefault();
      return;
    }

    const isAtTop = menu.scrollTop <= 0;
    const isAtBottom =
      Math.ceil(menu.scrollTop + menu.clientHeight) >= menu.scrollHeight;

    if ((event.deltaY < 0 && isAtTop) || (event.deltaY > 0 && isAtBottom)) {
      event.preventDefault();
    }
  }

  function isDesktopLinkActive(categoryId: string, query?: string) {
    if (route.page !== "shop") return false;
    if (query) return activeCategory === categoryId && activeQuery === query;
    return activeCategory === categoryId && !activeQuery;
  }

  const activeDesktopMenu =
    desktopLinks.find((link) => link.id === activeMenu) ?? null;

  return (
    <header
      className={`site-header sticky top-0 z-50 border-b border-black/8 bg-white/95 backdrop-blur-xl ${
        route.page === "home" ? "site-header-home" : ""
      }`}
    >
      <div className="site-announcement-bar">
        FREE SHIPPING ON ORDERS ABOVE RS. 2,500
      </div>

      <div
        className="relative mx-auto hidden min-h-[84px] max-w-[1700px] items-center gap-8 px-8 lg:flex xl:px-12"
        onMouseLeave={() => setActiveMenu(null)}
      >
        <a href="#/" className="site-wordmark shrink-0">
          Aylee
        </a>

        <nav className="site-desktop-nav" aria-label="Primary navigation">
          {desktopLinks.map((link) => (
            <button
              key={link.id}
              type="button"
              onMouseEnter={() => setActiveMenu(link.id)}
              onMouseLeave={() => setActiveMenu(null)}
              onFocus={() => setActiveMenu(link.id)}
              onClick={() => onShopCategory(link.categoryId, link.query)}
              className={`site-nav-link-minimal ${
                isDesktopLinkActive(link.categoryId, link.query) ? "is-active" : ""
              }`}
            >
              {link.label}
            </button>
          ))}
          <a
            href="#/about"
            onMouseEnter={() => setActiveMenu(null)}
            className="site-nav-link-minimal"
          >
            STORES
          </a>
          <a
            href="#/contact"
            onMouseEnter={() => setActiveMenu(null)}
            className="site-nav-link-minimal"
          >
            CONTACT
          </a>
        </nav>

        <div className="flex shrink-0 items-center gap-2">
          <a
            href="#/shop"
            className="site-icon-link"
            aria-label="Search products"
          >
            <SearchIcon />
          </a>
          <a
            href="#/wishlist"
            className="site-icon-link"
            aria-label={`Wishlist, ${wishlistCount} items`}
          >
            <HeartIcon />
            {wishlistCount > 0 && (
              <span className="site-icon-badge">{wishlistCount}</span>
            )}
          </a>
          <a
            href="#/account"
            className="site-icon-link"
            aria-label="Account login and sign up"
          >
            <UserIcon />
          </a>
          <button
            type="button"
            onClick={onOpenCart}
            className="site-icon-link"
            aria-label={`Open bag, ${cartCount} items`}
          >
            <BagIcon />
            {cartCount > 0 && <span className="site-icon-badge">{cartCount}</span>}
          </button>
        </div>

        {activeDesktopMenu && (
          <div className="site-mega-menu" onWheel={keepMegaMenuScroll}>
            <div className="site-mega-menu-grid">
              <div className="site-mega-list">
                {activeDesktopMenu.items.map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => onShopCategory(item.categoryId, item.query)}
                    className="site-mega-link"
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() =>
                  onShopCategory(
                    activeDesktopMenu.categoryId,
                    activeDesktopMenu.query,
                  )
                }
                className="site-mega-preview"
              >
                <img
                  src={activeDesktopMenu.hero}
                  alt={activeDesktopMenu.title}
                  className="site-mega-preview-image"
                />
                <div className="site-mega-preview-overlay" />
                <div className="site-mega-preview-copy">
                  <p className="site-mega-preview-label">{activeDesktopMenu.title}</p>
                  <span className="site-mega-preview-cta">SHOP NOW</span>
                </div>
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="mx-auto flex min-h-[72px] max-w-7xl items-center justify-between gap-3 px-4 lg:hidden sm:px-6">
        <a
          href="#/"
          className="site-wordmark text-[1.55rem]"
          aria-label="Aylee home"
        >
          Aylee
        </a>

        <div className="flex items-center gap-1.5">
          <a
            href="#/wishlist"
            className="site-mobile-icon"
            aria-label={`Wishlist, ${wishlistCount} items`}
          >
            <HeartIcon />
            {wishlistCount > 0 && (
              <span className="site-icon-badge">{wishlistCount}</span>
            )}
          </a>
          <button
            type="button"
            onClick={onOpenCart}
            className="site-mobile-icon"
            aria-label={`Open bag, ${cartCount} items`}
          >
            <BagIcon />
            {cartCount > 0 && <span className="site-icon-badge">{cartCount}</span>}
          </button>
          <button
            type="button"
            aria-label="Toggle menu"
            onClick={() => setMenuOpen((prev) => !prev)}
            className="site-mobile-icon"
          >
            <span className="space-y-1.5">
              <span className="site-menu-bar block h-0.5 w-5" />
              <span className="site-menu-bar block h-0.5 w-5" />
              <span className="site-menu-bar block h-0.5 w-5" />
            </span>
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="border-t border-black/8 bg-white/98 px-4 py-4 shadow-[0_24px_50px_-40px_rgba(0,0,0,0.5)] backdrop-blur lg:hidden sm:px-6">
          <div className="grid gap-2 text-[11px] font-semibold tracking-[0.18em] sm:grid-cols-2">
            {desktopLinks.map((link) => (
              <button
                key={link.id}
                type="button"
                onClick={() => {
                  closeMenu();
                  onShopCategory(link.categoryId, link.query);
                }}
                className={`rounded-[var(--radius-sm)] border px-4 py-3 text-center transition-colors ${
                  isDesktopLinkActive(link.categoryId, link.query)
                    ? "border-[var(--ink)] bg-[var(--ink)] text-[var(--paper)]"
                    : "border-black/10 bg-white"
                }`}
              >
                {link.label}
              </button>
            ))}
            {navLinks
              .filter((link) => link.href !== "#/shop")
              .map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={closeMenu}
                  className={`rounded-[var(--radius-sm)] border px-4 py-3 text-center transition-colors ${
                    isActive(link.href)
                      ? "border-[var(--ink)] bg-[var(--ink)] text-[var(--paper)]"
                      : "border-black/10 bg-white"
                  }`}
                >
                  {link.label}
                </a>
              ))}
          </div>

          <div className="mt-3 grid gap-2 text-[11px] font-semibold tracking-[0.16em] sm:grid-cols-2">
            <a
              href="#/shop"
              onClick={closeMenu}
              className="rounded-[var(--radius-sm)] border border-black/10 bg-white px-4 py-3 text-center"
            >
              SEARCH PRODUCTS
            </a>
            <a
              href="#/account"
              onClick={closeMenu}
              className="rounded-[var(--radius-sm)] border border-black/10 px-4 py-3 text-center"
            >
              LOGIN / SIGN UP
            </a>
            <a
              href="#/wishlist"
              onClick={closeMenu}
              className="rounded-[var(--radius-sm)] border border-black/10 px-4 py-3 text-center"
            >
              SAVED {wishlistCount}
            </a>
            <button
              type="button"
              onClick={() => {
                closeMenu();
                onOpenCart();
              }}
              className="rounded-[var(--radius-sm)] border border-black/10 px-4 py-3 text-center"
            >
              BAG {cartCount}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
